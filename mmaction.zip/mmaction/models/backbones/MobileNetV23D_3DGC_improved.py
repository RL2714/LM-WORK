"""ES_3D paper reproduction, based on the recovered 2023 CMTBR source.

Legacy state_dict names and the requested width=0.5 are retained. The spatial
Softmax axis, channel/time layout, returned weighted features, and attention
execution on all designated blocks are repaired explicitly.
"""
import math
import torch
import torch.nn as nn
from ..builder import BACKBONES


class ContextBlock(nn.Module):
    def __init__(self, inplanes, ratio=1/8):
        super().__init__()
        self.inplanes = inplanes
        self.planes = max(1, int(inplanes * ratio))
        self.conv_mask1 = nn.Sequential(nn.Conv3d(inplanes, inplanes, 3, padding=1, dilation=1))
        self.conv_mask2 = nn.Sequential(nn.Conv3d(inplanes, inplanes, 3, padding=3, dilation=3))
        self.conv_mask3 = nn.Sequential(nn.Conv3d(3*inplanes, inplanes, 1))
        # Kept for compatibility with the recovered checkpoint layout; not used.
        self.conv_mask = nn.Conv3d(inplanes, 1, 1)
        self.channel_add_conv = nn.Sequential(
            nn.Conv3d(inplanes, self.planes, 1),
            nn.BatchNorm3d(self.planes),
            nn.ReLU(inplace=True),
            nn.Conv3d(self.planes, 1, 1))
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x):
        fused = self.conv_mask3(torch.cat([x, self.conv_mask1(x), self.conv_mask2(x)], dim=1))
        spatial_weights = self.softmax(self.channel_add_conv(fused).flatten(3))
        # N,C,T,S times N,1,T,S -> N,C,T,1,1. No channel/time reinterpretation.
        context = (x.flatten(3) * spatial_weights).sum(-1, keepdim=True).unsqueeze(-1)
        # The paper shows elementwise multiplication, with no extra sigmoid.
        return x * context


def conv_bn(inp, oup, stride):
    return nn.Sequential(nn.Conv3d(inp, oup, 3, stride=stride, padding=1, bias=False),
                         nn.BatchNorm3d(oup), nn.ReLU6(inplace=True))


def conv_1x1x1_bn(inp, oup):
    return nn.Sequential(nn.Conv3d(inp, oup, 1, bias=False),
                         nn.BatchNorm3d(oup), nn.ReLU6(inplace=True))


class InvertedResidual(nn.Module):
    def __init__(self, inp, oup, stride, expand_ratio, attention=False):
        super().__init__()
        self.use_res_connect = stride == (1,1,1) and inp == oup
        hidden = round(inp * expand_ratio)
        if expand_ratio == 1:
            self.conv = nn.Sequential(
                nn.Conv3d(hidden, hidden, 3, stride, 1, groups=hidden, bias=False),
                nn.BatchNorm3d(hidden), nn.ReLU6(inplace=True),
                nn.Conv3d(hidden, oup, 1, bias=False), nn.BatchNorm3d(oup))
        else:
            self.conv = nn.Sequential(
                nn.Conv3d(inp, hidden, 1, bias=False), nn.BatchNorm3d(hidden), nn.ReLU6(inplace=True),
                nn.Conv3d(hidden, hidden, 3, stride, 1, groups=hidden, bias=False),
                nn.BatchNorm3d(hidden), nn.ReLU6(inplace=True),
                nn.Conv3d(hidden, oup, 1, bias=False), nn.BatchNorm3d(oup))
        if attention:
            self.ContextBlock = ContextBlock(oup)

    def forward(self, x):
        out = self.conv(x)
        if hasattr(self, 'ContextBlock'):
            out = self.ContextBlock(out)
        return x + out if self.use_res_connect else out


@BACKBONES.register_module()
class MobileNetV23D_3DGC_improved(nn.Module):
    def __init__(self, pretrained=None, width_mult=0.5, attention_stages=(0,1,2), num_classes=1000):
        super().__init__()
        if pretrained is not None:
            raise ValueError('This run starts from scratch; pretrained must be None.')
        self.pretrained = pretrained
        self.width_mult = width_mult
        settings = [(1,16,1,(1,1,1)), (6,24,2,(1,2,2)), (6,32,3,(1,2,2)),
                    (6,64,4,(1,2,2)), (6,96,3,(1,1,1)), (6,160,3,(1,1,1)),
                    (6,320,1,(1,1,1))]
        inp = int(32 * width_mult)
        features = [conv_bn(3, inp, (1,2,2))]
        for stage,(t,c,n,stride) in enumerate(settings):
            oup = int(c * width_mult)
            for i in range(n):
                features.append(InvertedResidual(inp,oup,stride if i==0 else (1,1,1),t,
                                                 attention=stage in attention_stages))
                inp = oup
        features.append(conv_1x1x1_bn(inp,640))
        self.features = nn.Sequential(*features)
        # Original unused classifier is retained to make parameter accounting explicit.
        self.classifier = nn.Sequential(nn.Dropout(.2),nn.Linear(640,num_classes))

    def init_weights(self):
        for m in self.modules():
            if isinstance(m,nn.Conv3d):
                nn.init.normal_(m.weight,0,math.sqrt(2.0/(math.prod(m.kernel_size)*m.out_channels)))
                if m.bias is not None:nn.init.zeros_(m.bias)
            elif isinstance(m,nn.BatchNorm3d):
                nn.init.ones_(m.weight);nn.init.zeros_(m.bias)
            elif isinstance(m,nn.Linear):
                nn.init.normal_(m.weight,0,.01)
                if m.bias is not None:nn.init.zeros_(m.bias)

    def forward(self,x):
        return self.features(x)
