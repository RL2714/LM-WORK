"""Literal Table 3 backbone from the manuscript; no implicit width multiplier."""
import torch.nn as nn
from ..builder import BACKBONES
from .MobileNetV23D_3DGC_improved import (
    ContextBlock, InvertedResidual, conv_bn, conv_1x1x1_bn,
    MobileNetV23D_3DGC_improved)


class PaperES3D(ContextBlock):
    def __init__(self,channels):
        super().__init__(channels,ratio=1/8)
        # The paper's diagram does not contain the legacy unused mask conv.
        del self.conv_mask


@BACKBONES.register_module()
class CMTBRTable3Backbone(MobileNetV23D_3DGC_improved):
    def __init__(self,pretrained=None):
        nn.Module.__init__(self)
        if pretrained is not None:raise ValueError('Table 3 experiment starts from scratch')
        self.pretrained=None
        self.architecture_table=[
            dict(layer=1,module='CBR',channels=16,repeats=1,stride=(1,2,2)),
            dict(layer=2,module='DW_3D_ES',channels=16,repeats=1,stride=(1,1,1),expansion=1),
            dict(layer=3,module='DSC_ES_3D',channels=24,repeats=2,stride=(1,2,2),expansion=6),
            dict(layer=4,module='DSC_ES_3D',channels=32,repeats=3,stride=(1,2,2),expansion=6),
            dict(layer=5,module='DSC_3D',channels=64,repeats=4,stride=(1,2,2),expansion=6),
            dict(layer=6,module='DSC_3D',channels=96,repeats=3,stride=(1,1,1),expansion=6),
            dict(layer=7,module='DSC_3D',channels=160,repeats=3,stride=(1,1,1),expansion=6),
            dict(layer=8,module='DSC_3D',channels=320,repeats=1,stride=(1,1,1),expansion=6),
            dict(layer=9,module='CBR',channels=640,repeats=1,stride=(1,1,1))]
        features=[conv_bn(3,16,(1,2,2))]
        inp=16
        for stage in self.architecture_table[1:-1]:
            for i in range(stage['repeats']):
                block=InvertedResidual(inp,stage['channels'],stage['stride'] if i==0 else (1,1,1),
                                       stage['expansion'],attention=False)
                if stage['module'] in ['DW_3D_ES','DSC_ES_3D']:
                    block.ContextBlock=PaperES3D(stage['channels'])
                features.append(block);inp=stage['channels']
        features.append(conv_1x1x1_bn(inp,640))
        self.features=nn.Sequential(*features)
        # Only the 2-class light head is used. No unused 1000-class classifier.
