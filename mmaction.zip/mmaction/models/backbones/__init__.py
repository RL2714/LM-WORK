# Copyright (c) OpenMMLab. All rights reserved.
from .agcn import AGCN
from .c3d import C3D
from .mobilenet_v2 import MobileNetV2
from .mobilenet_v2_tsm import MobileNetV2TSM
#from .mobilenet_v2 import MobileNetV2_improve
from .resnet import ResNet
from .resnet2plus1d import ResNet2Plus1d
from .resnet3d import ResNet3d, ResNet3dLayer
from .resnet3d_csn import ResNet3dCSN
from .resnet3d_slowfast import ResNet3dSlowFast
from .resnet3d_slowonly import ResNet3dSlowOnly
from .resnet_audio import ResNetAudio
from .resnet_tin import ResNetTIN
from .resnet_tsm import ResNetTSM
from .stgcn import STGCN
from .tanet import TANet
from .timesformer import TimeSformer
from .x3d import X3D
from .mobilenetv2 import MobileNetV23D
from .MobileNetV23D_3DGC import MobileNetV23D_3DGC
from .MobileNetV2TSM_improve import MobileNetV2TSM_improve
from .mobilenetv2_improve import MobileNetV2_improve

__all__ = [
    'C3D', 'ResNet', 'ResNet3d', 'ResNetTSM', 'ResNet2Plus1d',
    'ResNet3dSlowFast', 'ResNet3dSlowOnly', 'ResNet3dCSN', 'ResNetTIN', 'X3D', 'MobileNetV23D_3DGC',
    'ResNetAudio', 'ResNet3dLayer', 'MobileNetV2TSM', 'MobileNetV2', 'TANet','MobileNetV2_improve',
    'TimeSformer', 'STGCN', 'MobileNetV23D', 'AGCN','MobileNetV2TSM_improve'
]
