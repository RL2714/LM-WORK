'''MobilenetV2 in PyTorch.

See the paper "MobileNetV2: Inverted Residuals and Linear Bottlenecks" for more details.
'''
import torch
import math
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
from mmcv.cnn import ConvModule, constant_init, kaiming_init
from mmcv.runner import _load_checkpoint, load_checkpoint
from mmcv.utils import _BatchNorm
from torch.utils import checkpoint as cp

from ...utils import get_root_logger
from ..builder import BACKBONES
class ContextBlock(nn.Module):
    def __init__(self, inplanes, ratio, T=16, pooling_type='att',
                 fusion_types=('channel_add',)):
        super(ContextBlock, self).__init__()
        valid_fusion_types = ['channel_add', 'channel_mul']

        assert pooling_type in ['avg', 'att']
        assert isinstance(fusion_types, (list, tuple))
        assert all([f in valid_fusion_types for f in fusion_types])
        assert len(fusion_types) > 0, 'at least one fusion should be used'

        self.inplanes = inplanes
        self.ratio = ratio
        self.planes = int(inplanes * ratio)
        self.pooling_type = pooling_type
        self.fusion_types = fusion_types

        if pooling_type == 'att':
            self.conv_mask = nn.Conv3d(inplanes, 1, kernel_size=1)
            self.softmax = nn.Softmax()
        else:
            self.avg_pool = nn.AdaptiveAvgPool2d(1)
        if 'channel_add' in fusion_types:
            self.channel_add_conv = nn.Sequential(
                nn.Conv3d(self.inplanes, self.planes, kernel_size=1),
                nn.LayerNorm([self.planes, T, 1, 1]),
                nn.ReLU(inplace=True),  # yapf: disable
                nn.Conv3d(self.planes, self.inplanes, kernel_size=1))
        else:
            self.channel_add_conv = None
        if 'channel_mul' in fusion_types:
            self.channel_mul_conv = nn.Sequential(
                nn.Conv3d(self.inplanes, self.planes, kernel_size=1),
                nn.LayerNorm([self.planes, 1, 1]),
                nn.ReLU(inplace=True),  # yapf: disable
                nn.Conv3d(self.planes, self.inplanes, kernel_size=1))
        else:
            self.channel_mul_conv = None

    def forward(self, x):
        batch, channel, T, height, width = x.size()
        if self.pooling_type == 'att':
           # print('2222222222222222222')
            input_x = x
            # [N, T, C,  H * W]
            input_x = input_x.view(batch, T, channel, height * width)
            # [N, 1, T, C, H * W]
            input_x = input_x.unsqueeze(1)
            # [N, 1, T, H, W]
            context_mask = self.conv_mask(x)
            # [N, 1, T, H * W]
            context_mask = context_mask.view(batch, 1, T, height * width)
            # [N, 1, T, H * W]
            context_mask = self.softmax(context_mask)
            # [N, 1, T, H * W, 1]
            context_mask = context_mask.unsqueeze(-1)
            # [N, 1, T, C,  1]
            context = torch.matmul(input_x, context_mask)
            # [N, C, T, 1, 1]
            context = context.view(batch, channel, T, 1, 1)
        else:
            # [N, C, T, 1, 1]
           # print('2222222222222222222')
            context = self.avg_pool(x)
        return context


def conv_bn(inp, oup, stride):
    return nn.Sequential(
        nn.Conv3d(inp, oup, kernel_size=3, stride=stride, padding=(1,1,1), bias=False),
        nn.BatchNorm3d(oup),
        nn.ReLU6(inplace=True)
    )


def conv_1x1x1_bn(inp, oup):
    return nn.Sequential(
        nn.Conv3d(inp, oup, 1, 1, 0, bias=False),
        nn.BatchNorm3d(oup),
        nn.ReLU6(inplace=True)
    )


class InvertedResidual(nn.Module):
    def __init__(self, inp, oup, stride, expand_ratio, GC_ratio=None):
        super(InvertedResidual, self).__init__()
        self.stride = stride
        self.GC = GC_ratio

        hidden_dim = round(inp * expand_ratio)
        self.use_res_connect = self.stride == (1,1,1) and inp == oup

        if expand_ratio == 1:
            self.conv = nn.Sequential(
                # dw
                nn.Conv3d(hidden_dim, hidden_dim, 3, stride, 1, groups=hidden_dim, bias=False),
                nn.BatchNorm3d(hidden_dim),
                nn.ReLU6(inplace=True),
                # pw-linear
                nn.Conv3d(hidden_dim, oup, 1, 1, 0, bias=False),
                nn.BatchNorm3d(oup),
            )
        else:
            self.conv = nn.Sequential(
                # pw
                nn.Conv3d(inp, hidden_dim, 1, 1, 0, bias=False),
                nn.BatchNorm3d(hidden_dim),
                nn.ReLU6(inplace=True),
                # dw
                nn.Conv3d(hidden_dim, hidden_dim, 3, stride, 1, groups=hidden_dim, bias=False),
                nn.BatchNorm3d(hidden_dim),
                nn.ReLU6(inplace=True),
                # pw-linear
                nn.Conv3d(hidden_dim, oup, 1, 1, 0, bias=False),
                nn.BatchNorm3d(oup),
            )
        if self.GC is not None:
            #self.se_module = SEModule(planes, self.se_ratio)
           # print('1111111111111111')
            self.ContextBlock = ContextBlock(oup, ratio=1./16., pooling_type='att')

    def forward(self, x):
        out = self.conv(x)
        #print(out.size())
        if self.use_res_connect:
            if self.GC is not None:
                out = self.ContextBlock(out)
            return x + out
        else:
            return out

@BACKBONES.register_module()
class MobileNetV23D_3DGC(nn.Module):
    def __init__(self, num_classes=1000, sample_size=224, pretrained=None, width_mult=0.5):
        super(MobileNetV23D_3DGC, self).__init__()
        block = InvertedResidual
        input_channel = 32
        self.out_indices = (7, )
        self.frozen_stages=-1
        self.pretrained =pretrained
        self.norm_eval=False
        last_channel = 640
        interverted_residual_setting = [
            # t, c, n, s
            [1,  16, 1, (1,1,1), None],
            [6,  24, 2, (1,2,2), None],
            [6,  32, 3, (1,2,2), 0.2],
            [6,  64, 4, (1,2,2), None],
            [6,  96, 3, (1,1,1), 0.2],
            [6, 160, 3, (1,1,1), None],
            [6, 320, 1, (1,1,1), None],
        ]
        self.partial_bn=False
        # building first layer
        assert sample_size % 16 == 0.
        input_channel = int(input_channel * width_mult)
        self.last_channel = int(last_channel * width_mult) if width_mult > 1.0 else last_channel
        self.features = [conv_bn(3, input_channel, (1,2,2))]
        # building inverted residual blocks
        for t, c, n, s, g in interverted_residual_setting:
            output_channel = int(c * width_mult)
            for i in range(n):
                stride = s if i == 0 else (1,1,1)
                self.features.append(block(input_channel, output_channel, stride, expand_ratio=t, GC_ratio=g))
                input_channel = output_channel
        # building last several layers
        self.features.append(conv_1x1x1_bn(input_channel, self.last_channel))
        # make it nn.Sequential
        self.features = nn.Sequential(*self.features)

        # building classifier
        self.classifier = nn.Sequential(
            nn.Dropout(0.2),
            nn.Linear(self.last_channel, num_classes),
        )

        self.init_weights()

    def forward(self, x):
        #print(x.size())
        x = self.features(x)
        #for i, layer_name in enumerate(self.features):
            #print('333333333333')
           # x = layer_name(x)
            #print(x.size())
        # x = F.avg_pool3d(x, x.data.size()[-3:])
        # x = x.view(x.size(0), -1)
        # x = self.classifier(x)
        #print(x.size())

        #return tuple(outs)
        return x
    def init_weights(self):
        """Initiate the parameters either from existing checkpoint or from
        scratch."""
        if isinstance(self.pretrained, str):
            logger = get_root_logger()
            load_checkpoint(self, self.pretrained, strict=False, logger=logger)
        elif self.pretrained is None:
            for m in self.modules():
                if isinstance(m, nn.Conv3d):
                    n = m.kernel_size[0] * m.kernel_size[1] * m.kernel_size[2] * m.out_channels
                    m.weight.data.normal_(0, math.sqrt(2. / n))
                    if m.bias is not None:
                        m.bias.data.zero_()
                elif isinstance(m, nn.BatchNorm3d):
                    m.weight.data.fill_(1)
                    m.bias.data.zero_()
                elif isinstance(m, nn.Linear):
                    n = m.weight.size(1)
                    m.weight.data.normal_(0, 0.01)
                    m.bias.data.zero_()
    def _freeze_stages(self):
        """Prevent all the parameters from being optimized before
        ``self.frozen_stages``."""
        if self.frozen_stages >= 0:
            self.conv1.bn.eval()
            for m in self.conv1.modules():
                for param in m.parameters():
                    param.requires_grad = False

        for i in range(1, self.frozen_stages + 1):
            m = getattr(self, f'layer{i}')
            m.eval()
            for param in m.parameters():
                param.requires_grad = False

    def _partial_bn(self):
        logger = get_root_logger()
        logger.info('Freezing BatchNorm2D except the first one.')
        count_bn = 0
        for m in self.modules():
            if isinstance(m, nn.BatchNorm2d):
                count_bn += 1
                if count_bn >= 2:
                    m.eval()
                    # shutdown update in frozen mode
                    m.weight.requires_grad = False
                    m.bias.requires_grad = False

    def train(self, mode=True):
        """Set the optimization status when training."""
        super().train(mode)
        self._freeze_stages()
        if mode and self.norm_eval:
            for m in self.modules():
                if isinstance(m, _BatchNorm):
                    m.eval()
        if mode and self.partial_bn:
            self._partial_bn()


def get_fine_tuning_parameters(model, ft_portion):
    if ft_portion == "complete":
        return model.parameters()

    elif ft_portion == "last_layer":
        ft_module_names = []
        ft_module_names.append('classifier')

        parameters = []
        for k, v in model.named_parameters():
            for ft_module in ft_module_names:
                if ft_module in k:
                    parameters.append({'params': v})
                    break
            else:
                parameters.append({'params': v, 'lr': 0.0})
        return parameters

    else:
        raise ValueError("Unsupported ft_portion: 'complete' or 'last_layer' expected")

    
# def get_model(**kwargs):
#     """
#     Returns the model.
#     """
#     model = MobileNetV2(**kwargs)
#     return model


# if __name__ == "__main__":
#     model = get_model(num_classes=600, sample_size=112, width_mult=1.)
#     model = model.cuda()
#     model = nn.DataParallel(model, device_ids=None)
#     print(model)


#     input_var = Variable(torch.randn(8, 3, 16, 112, 112))
#     output = model(input_var)
#     print(output.shape)

